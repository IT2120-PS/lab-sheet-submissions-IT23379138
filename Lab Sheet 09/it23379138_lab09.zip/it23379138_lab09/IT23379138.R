setwd("C:\\Users\\oshad\\OneDrive\\Desktop\\it23379138_lab09")
getwd()
# Set seed for reproducibility
set.seed(123)
# Part (i) Generate random sample
sample_size <- 25
mu <- 45
sigma <- 2
baking_times <- rnorm(sample_size, mean = mu, sd = sigma)
print(baking_times)
t_test_result <- t.test(baking_times, mu = 46, alternative = "less")
print(t_test_result)
savehistory("C:/Users/oshad/OneDrive/Desktop/it23379138_lab09/IT23379138.R")
